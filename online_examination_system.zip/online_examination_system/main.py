import tkinter as tk
from tkinter import messagebox, ttk
import random
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def load_questions():
    try:
        with open("questions.json", "r") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        messagebox.showerror("Error", "Failed to load questions.json! Check the file and try again.")
        return {}

def goto_test_page():
    landing_frame.pack_forget()
    main_frame.pack(expand=True, fill=tk.BOTH)

def start_test():
    global questions_list, user_answers, current_page, timer_running, time_remaining
    category = category_var.get()
    if not category:
        messagebox.showwarning("Warning", "Please select a category!")
        return
    
    if category in questions and len(questions[category]) >= 12:
        questions_list = random.sample(questions[category], 12)
    else:
        messagebox.showerror("Error", f"Not enough questions in {category}. Available: {len(questions.get(category, []))}")
        return
    
    # Initialize user_answers with StringVar
    user_answers = {idx: tk.StringVar(root) for idx in range(len(questions_list))}

    current_page = 0
    display_questions()
    timer_running = True
    time_remaining = 15 * 60
    start_timer()

    # Show navigation buttons when test starts
    prev_button.pack(side=tk.LEFT, padx=10, pady=5)
    submit_button.pack(side=tk.LEFT, padx=10, pady=5, expand=True)
    next_button.pack(side=tk.RIGHT, padx=10, pady=5)

def start_timer():
    global time_remaining, timer_running
    if time_remaining > 0 and timer_running:
        minutes, seconds = divmod(time_remaining, 60)
        timer_label.config(text=f"Time Remaining: {minutes:02}:{seconds:02}")
        time_remaining -= 1
        root.after(1000, start_timer)
    elif timer_running:
        submit_test()

def display_questions():
    for widget in scrollable_frame.winfo_children():
        widget.destroy()
    
    start_idx = current_page * questions_per_page
    end_idx = min(start_idx + questions_per_page, len(questions_list))
    
    for idx in range(start_idx, end_idx):
        q = questions_list[idx]
        tk.Label(scrollable_frame, text=f"Q{idx+1}: {q['question']}", font=("Arial", 12, "bold"), wraplength=700).pack(anchor="w", pady=10)
        
        # Ensure `user_answers[idx]` exists
        if idx not in user_answers:
            user_answers[idx] = tk.StringVar(root)

        for option in q['options']:
            tk.Radiobutton(scrollable_frame, text=option, variable=user_answers[idx], value=option).pack(anchor='w', padx=30, pady=2)
    
    prev_button.config(state=tk.NORMAL if current_page > 0 else tk.DISABLED)
    next_button.config(state=tk.NORMAL if end_idx < len(questions_list) else tk.DISABLED)

def prev_page():
    global current_page
    if current_page > 0:
        current_page -= 1
        display_questions()

def next_page():
    global current_page
    if (current_page + 1) * questions_per_page < len(questions_list):
        current_page += 1
        display_questions()

def submit_test():
    global timer_running
    timer_running = False
    score = sum(1 for idx, q in enumerate(questions_list) if user_answers[idx].get() == q['answer'])
    total = len(questions_list)
    messagebox.showinfo("Result", f"You scored {score}/{total}")
    display_graph(score, total - score)

def display_graph(correct, incorrect):
    fig, ax = plt.subplots(figsize=(4, 3))
    ax.bar(["Correct", "Incorrect"], [correct, incorrect], color=['green', 'red'])
    ax.set_ylabel("Number of Questions")
    ax.set_title("Test Performance")
    
    global graph_canvas
    if 'graph_canvas' in globals():
        graph_canvas.get_tk_widget().pack_forget()
    
    graph_canvas = FigureCanvasTkAgg(fig, master=root)
    graph_canvas.draw()
    graph_canvas.get_tk_widget().pack(pady=10)

# Initialize Tkinter
root = tk.Tk()
root.title("Mock Test System")
root.geometry("800x600")

questions = load_questions()
questions_list = []
user_answers = {}
current_page = 0
questions_per_page = 4
time_remaining = 15 * 60
timer_running = False

# Landing Page
landing_frame = tk.Frame(root, padx=20, pady=20, bg="lightblue")
landing_frame.pack(expand=True, fill="both")

tk.Label(landing_frame, text="Best way to predict your future is to create it", font=("Helvetica", 18, "bold"), bg="lightblue").pack(pady=100)

tk.Button(landing_frame, text="Take Your Exam", command=goto_test_page, font=("Arial", 14), bg="blue", fg="white", height=2, width=20).pack()

# Test Page
main_frame = tk.Frame(root, padx=20, pady=20)

timer_label = tk.Label(main_frame, text="Time Remaining: 15:00", font=("Arial", 12, "bold"))
timer_label.pack(pady=5)

category_var = tk.StringVar()
tk.Label(main_frame, text="Select Category:", font=("Arial", 14, "bold")).pack(pady=5)
category_dropdown = ttk.Combobox(main_frame, textvariable=category_var, values=list(questions.keys()), state='readonly')
category_dropdown.pack(pady=5)

tk.Button(main_frame, text="Start Test", command=start_test, font=("Arial", 12), bg="blue", fg="white").pack(pady=10)

canvas = tk.Canvas(main_frame)
scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
scrollable_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
def update_scroll_region(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

scrollable_frame.bind("<Configure>", update_scroll_region)

canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

nav_frame = tk.Frame(main_frame)
nav_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=10)

# Navigation Buttons (Initially Hidden)
prev_button = tk.Button(nav_frame, text="Previous", command=prev_page)
submit_button = tk.Button(nav_frame, text="Submit Test", command=submit_test, font=("Arial", 12), bg="green", fg="white")
next_button = tk.Button(nav_frame, text="Next", command=next_page)

root.mainloop()
